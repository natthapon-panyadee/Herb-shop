<?php  
	require_once('../dbconfig.php');

	if (isset($_GET['id'])) {
		$sql = "DELETE FROM cart WHERE cart_id = ".$_GET['id'];
		$conn->query($sql);
		header('location:../cart.php');
	}


?>