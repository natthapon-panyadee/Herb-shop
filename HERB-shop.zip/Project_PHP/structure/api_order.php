<?php
session_start();
	// require_once '/connectDB.php';
if (file_exists('../dbconfig.php')) {
    require('../dbconfig.php'); // This is line 38
}
	if (isset($_POST['sum'])){
		$sum = $_POST['sum'];
		$cart = $_POST['cart'];
		$user_id = $_SESSION['user'];
		
		$sql = "INSERT INTO order_list ( user_id, total_price,cart_id) VALUES ( '$user_id','$sum', '$cart')";
		echo $sql;
		if($conn->query($sql)){
			echo "สำเร็จ";
		}else{
			echo "ผิดพลาด";
		}
		
	}

?>