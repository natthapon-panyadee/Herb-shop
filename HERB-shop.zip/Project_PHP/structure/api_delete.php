<?php 
	require_once '../dbconfig.php';
	 if(isset($_GET['id'])){
        $id = $_GET['id'];
        $sql = "DELETE FROM order_list WHERE order_id = $id";
        $conn->query($sql);
        header('Location: ../admin.php');

      

     }
 ?>