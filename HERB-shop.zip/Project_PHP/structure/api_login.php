<?php

if (isset($_POST['inputUsername'])) {


    session_start();

    require_once('../dbconfig.php');


    $sql = "SELECT * FROM account_user WHERE user_name = '" . $_POST['inputUsername'] . "'";
    if ($result = $conn->query($sql)) {
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // $_SESSION['admin'] = $row['admin_user'];
                $_SESSION['type'] = $row['type'];
                $_SESSION['user'] = $row['user_id'];
                
                

                // header("Location:Homepage.php");
            }
            echo "เข้าสู่ระบบสำเร็จ";
        } else {
            echo "ชื่อผู้ใช้งาน หรือรหัสผ่าน ไม่ถูกต้อง";
        }
    } else {
        echo "server error";
    }
    $conn->close();
}
?>