<?php

require_once('../dbconfig.php');

session_start();

if (isset($_POST['inputid'])) {

    $inputid = $_POST['inputid'];
    $quantity_value = $_POST['inputGroupSelect01'];


    $user_id = $_SESSION['user'];


    $sql = "INSERT INTO cart ( item_id , user_id ,qty) VALUES ( '$inputid', '$user_id','$quantity_value')";
    echo $sql;
    if ($conn->query($sql)) {
        echo "เพิ่มสินค้าสำเร็จ";
    } else {
        echo "เพิ่มสินค้าผิดพลาด";
    }
}
?>