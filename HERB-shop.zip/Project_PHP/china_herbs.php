<!DOCTYPE html>
<html lang="en">
    <title>สมุนไพรจีน</title>
    <?php
    // put your code here
    require_once('structure/head.php');
    ?>

    <body>

        <div class="super_container">

            <!-- Header -->
            <header class="header trans_300">
                <div class="top_nav">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-right">
                                <div class="top_nav_right">
                                    <ul class="top_nav_menu">


                                        <li class="account">
                                            <a href="#">
                                                My Account
                                                <i class="fa fa-angle-down"></i>
                                            </a>
                                            <ul class="account_selection">
                                                <?php
                                                require_once('structure/header_1.php');
                                                ?>

                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 


                <!-- Main Navigation -->
                <?php
                require_once('structure/subheader.php');
                ?>

            </header><br><br>

            <br><br>

            <div class="benefit">
                <div class="container">
                    <div class="row benefit_row">
                        <div class="col-lg-12 benefit_col">



                            <div class="row">
                                <div class="col">
                                    <div class="product-grid" data-isotope='{ "itemSelector": ".product-item", "layoutMode": "fitRows" }'>


                                        <?php
                                        require_once'dbconfig.php';
                                        $sql = "SELECT * FROM item WHERE type_disease = 'สมุนไพรจีน' ORDER by item_id   ";
                                        if ($result = $conn->query($sql)) {
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    ?>
                                                    <div class="product-item men">
                                                        <div class="product discount product_filter">
                                                            <div class="product_image">
                                                                <img src="images/<?php echo $row['item_image'] ?> " alt="">
                                                            </div>
                                                            <div class="favorite favorite_left"></div>
                <!--                                                    <div class="product_bubble product_bubble_right product_bubble_red d-flex flex-column align-items-center"><span>-$20</span></div>-->
                                                            <div class="product_info">
                                                                <h6 class="product_name"><a href="single.php?id=<?php echo $row['item_id'] ?>  ">  <?php echo $row['item_name'] ?> </a></h6>
                                                                <div class="product_price"><?php echo $row['item_price'] ?>  บาท</div>
                                                            </div>
                                                        </div>
                                                        <div class="red_button add_to_cart_button"><a href="single.php?id=<?php echo $row['item_id'] ?>  ">add to cart</a></div>
                                                    </div>

                                                    <?php
                                                }
                                            }
                                        }
                                        ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Benefit -->

            <div class="benefit">
                <div class="container">
                    <div class="row benefit_row">
                        <div class="col-lg-3 benefit_col">
                            <div class="benefit_item d-flex flex-row align-items-center">
                                <div class="benefit_icon"><i class="fa fa-truck" aria-hidden="true"></i></div>
                                <div class="benefit_content">
                                    <h6>free shipping</h6>
                                    <p>Suffered Alteration in Some Form</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 benefit_col">
                            <div class="benefit_item d-flex flex-row align-items-center">
                                <div class="benefit_icon"><i class="fa fa-money" aria-hidden="true"></i></div>
                                <div class="benefit_content">
                                    <h6>cach on delivery</h6>
                                    <p>The Internet Tend To Repeat</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 benefit_col">
                            <div class="benefit_item d-flex flex-row align-items-center">
                                <div class="benefit_icon"><i class="fa fa-undo" aria-hidden="true"></i></div>
                                <div class="benefit_content">
                                    <h6>45 days return</h6>
                                    <p>Making it Look Like Readable</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 benefit_col">
                            <div class="benefit_item d-flex flex-row align-items-center">
                                <div class="benefit_icon"><i class="fa fa-clock-o" aria-hidden="true"></i></div>
                                <div class="benefit_content">
                                    <h6>opening all week</h6>
                                    <p>24 HOUR</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <br><br><br>


        </div>

        <script src="js/jquery-3.2.1.min.js"></script>
        <script src="styles/bootstrap4/popper.js"></script>
        <script src="styles/bootstrap4/bootstrap.min.js"></script>
        <script src="plugins/Isotope/isotope.pkgd.min.js"></script>
        <script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
        <script src="plugins/easing/easing.js"></script>
        <script src="js/custom.js"></script>
    </body>

</html>
