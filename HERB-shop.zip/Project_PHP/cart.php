
<?php ?>

<!DOCTYPE html>
<html>
    <head>
        <title>ตะกร้าสินค้า</title>
        <meta charset="utf-8">

        <?php
        // put your code here
        require_once('structure/head.php');
        
        ?>


        <link rel="stylesheet" type="text/css" href="js/cart.js">
        <link rel="stylesheet" type="text/css" href="css/cart.css">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Colo Shop Template">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
        <link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
        <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
        <link rel="stylesheet" type="text/css" href="styles/main_styles.css">
        <link rel="stylesheet" type="text/css" href="styles/responsive.css">
        <link href="https://fonts.googleapis.com/css?family=Krub|Roboto" rel="stylesheet">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    </head>
    <body>

        <div class="super_container">

            <!-- Header -->

            <header class="header trans_300">

                <div class="top_nav">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">

                                <!--ใส่ได้-->


                            </div>
                            <div class="col-md-6 text-right">
                                <div class="top_nav_right">
                                    <ul class="top_nav_menu">


                                        <li class="account">
                                            <a href="#">
                                                My Account
                                                <i class="fa fa-angle-down"></i>
                                            </a>
                                            <ul class="account_selection">
                                                <?php
                                                require_once('structure/header_1.php');
                                                ?>

                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Main Navigation -->

                <?php
                require_once('structure/subheader.php');
                ?>

            </header>
        </div>

        <div class="wrap cf">
            <h1 class="projTitle">คำนวณราคาสินค้าทั้งหมด</h1>
            <div class="heading cf">
                <h1>My Cart</h1>
                <a href="Homepage.php" class="continue">Continue Shopping</a>
            </div>
            <div class="cart">                   
                <ul class="cartWrap">
                    <?php
                    require_once('dbconfig.php');
                    $sql = "SELECT * FROM cart join item on cart.item_id = item.item_id join account_user on cart.user_id = account_user.user_id WHERE account_user.user_id =" . $_SESSION['user'];

                    $sum = 0;
                    $sum2 = 0;

                    if ($result = $conn->query($sql)) {
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <li class="items odd">

                                    <div class="infoWrap"> 
                                        <div class="cartSection">
                                            <img src="images/<?php echo $row['item_image'] ?>" alt="" class="itemImg" />
                                            <p class="itemNumber">#QUE-007544-002</p>
                                            <h3><?php echo $row['item_name'] ?></h3>

                                            <p> <input type="text"  class="qty" value="<?php echo $row['qty'] ?>" placeholder="1"/> x <?php echo $row['item_price'] ?></p>

                                            <p class="stockStatus"> In Stock</p>
                                        </div>  


                                        <div class="prodTotal cartSection">

                                            <p><?php echo $row['item_price'] ?></p>
                                            <?php $sum2 += ($row['user_id']) / $row['user_id'] ?>
                                            <?php $sum += ($row['item_price']) * $row['qty']; ?>

                                        </div>
                                        <div class="cartSection removeWrap">

                                            <a href="structure/api_deletecart.php?id=<?php echo $row['cart_id'] ?>"  class="remove" id="delete">  x </a>

                                            <input type="hidden" name="" id="sum" value="<?php echo $sum ?>">
                                            <input type="hidden" name="" id="cart" value=" <?php echo $row['cart_id'] ?>">

                                        </div>
                                    </div>
                                </li>
                                <?php
                            }
                        }
                    }
                    ?>

                    <!--<li class="items even">Item 2</li>-->

                </ul>
            </div>

<!--            <div class="promoCode"><label for="promo">Have A Promo Code?</label><input type="text" name="promo" placholder="Enter Code" />
                <a href="#" class="btn"></a>
            </div>-->

            <div class="subtotal cf">
                <ul>
                    <li class="totalRow"><span class="label">Subtotal</span><span class="value"><div> <?php echo $sum ?> </div>
                        </span></li>




                    <li class="totalRow final"><span class="label">Total</span><span class="value"><div> <?php echo $sum ?> </div>
                        </span></li>
                    <li class="totalRow"><a href="#" class="btn continue" id="addorder">Checkout</a></li>
                        <?php echo $sum2 ?>
                </ul>
            </div>
        </div>
        
    <!-- Benefit -->

            <div class="benefit">
                <div class="container">
                    <div class="row benefit_row">
                        <div class="col-lg-3 benefit_col">
                            <div class="benefit_item d-flex flex-row align-items-center">
                                <div class="benefit_icon"><i class="fa fa-truck" aria-hidden="true"></i></div>
                                <div class="benefit_content">
                                    <h6>free shipping</h6>
                                    <p>Suffered Alteration in Some Form</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 benefit_col">
                            <div class="benefit_item d-flex flex-row align-items-center">
                                <div class="benefit_icon"><i class="fa fa-money" aria-hidden="true"></i></div>
                                <div class="benefit_content">
                                    <h6>cach on delivery</h6>
                                    <p>The Internet Tend To Repeat</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 benefit_col">
                            <div class="benefit_item d-flex flex-row align-items-center">
                                <div class="benefit_icon"><i class="fa fa-undo" aria-hidden="true"></i></div>
                                <div class="benefit_content">
                                    <h6>45 days return</h6>
                                    <p>Making it Look Like Readable</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 benefit_col">
                            <div class="benefit_item d-flex flex-row align-items-center">
                                <div class="benefit_icon"><i class="fa fa-clock-o" aria-hidden="true"></i></div>
                                <div class="benefit_content">
                                    <h6>opening all week</h6>
                                    <p>24 HOUR</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <br><br><br>
    

    </body>

    <script type="text/javascript">
        $('#addorder').on('click', function () {

            var sum = $('#sum').val();
            var cart = $('#cart').val();


            $.ajax({
                type: "POST",
                url: "structure/api_order.php",
                data: {
                    'sum': sum,
                    'cart': cart,

                },
                success: function (data) {
                    alert(data);
                    window.location.href = "payment.php";
                },
            });
        });

    </script>




</html>