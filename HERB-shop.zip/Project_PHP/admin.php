<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Admin</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--===============================================================================================-->	
        <link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
        <!--===============================================================================================-->
        <link rel="stylesheet" type="text/css" href="css/admin/util.css">
        <link rel="stylesheet" type="text/css" href="css/admin/main.css">
        <!--===============================================================================================-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>

         <?php
    // put your code here
    require_once('structure/head.php');
    
    session_start();
    
    ?>

    </head>
    <body>

        <div class="super_container">

            <!-- Header -->

            <header class="header trans_300">

                <div class="top_nav">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">

                                <!--ใส่ได้-->


                            </div>
                            <div class="col-md-6 text-right">
                                <div class="top_nav_right">
                                    <ul class="top_nav_menu">


                                        <li class="account">
                                            <a href="#">
                                                My Account
                                                <i class="fa fa-angle-down"></i>
                                            </a>
                                            <ul class="account_selection">
                                                <?php
                                                require_once('structure/header_1.php');
                                                ?>

                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Main Navigation -->

                <?php
                require_once('structure/subheader.php');
                ?>

            </header>
        </div>
        
        <div class="limiter" style="background: -webkit-linear-gradient(bottom, #aab5ac, #39b549);">
            <div class="container-table100">
                <div class="wrap-table100">
                    <div class="table100 ver1">
                        

                      
                            <div class="table100-nextcols">
                                <table>
                                    <thead>
                                        <tr class="row100 head">
                                            <th class="cell100 column2">รหัสสั่งซื้อ</th>
                                            <th class="cell100 column3">รหัสตะกร้า</th>
                                            <th class="cell100 column4">จำนวนเงิน</th>
                                            <th class="cell100 column5"></th>
                                            
                                        </tr>
                                    </thead>
                                    <?php
				require_once'dbconfig.php';
                                if(isset($_SESSION['user'])){
				$sql = "SELECT * FROM order_list ";
					if($result=$conn->query($sql)){
						if($result->num_rows>0){
							while($row = $result->fetch_assoc()){
                                ?>
                                    <tbody>
                                        <tr class="row100 body">
                                            <td class="cell100 column2"><?php echo $row['order_id'] ?> </td>
                                            
                                            <td class="cell100 column4"><?php echo $row['cart_id'] ?> </td>
                                            <td class="cell100 column3"><?php echo $row['total_price'] ?>  บาท</td>
                                            <td class="cell100 column5"><a href="structure/api_delete.php?id=<?php echo $row['order_id'] ?>" class="btn btn-danger">ลบ</a> </td>
                                            
                                        </tr>

                                       
                                    </tbody>
                                    <?php 
                                                        }
                                                }
                                        }
                                }
                                    ?>
                                </table>
                            </div>
                       
                    </div>
                </div>
            </div>
        </div>




        



    </body>
</html>
