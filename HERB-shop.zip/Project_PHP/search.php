<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
if (isset($_POST['keyword']))
    $keyword = $_POST['keyword'];
else
    $keyword = "";
?>

<html>
    <head>
        <title>ค้นหาสินค้า</title>
        <?php
        // put your code here
        require_once('structure/head.php');
        require_once './dbconfig.php';
        ?>
        <title></title>
    </head>
    <body>



        <div class="super_container">

            <!-- Header -->
            <header class="header trans_300">
                <div class="top_nav">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-right">
                                <div class="top_nav_right">
                                    <ul class="top_nav_menu">


                                        <li class="account">
                                            <a href="#">
                                                My Account
                                                <i class="fa fa-angle-down"></i>
                                            </a>
                                            <ul class="account_selection">
                                                <?php
                                                require_once('structure/header_1.php');
                                                ?>

                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 


                <!-- Main Navigation -->
                <?php
                require_once('structure/subheader.php');
                ?>

            </header><br><br>

            <br><br>

             <div class="benefit">
                <div class="container">
                    <div class="row benefit_row">
                        <div class="col-lg-12 benefit_col">



                            <div class="row">
                                <div class="col">
                                    <div class="product-grid" data-isotope='{ "itemSelector": ".product-item", "layoutMode": "fitRows" }'>

                                        
                                        <?php
                                        
                                        require_once'dbconfig.php';

                                        $sql = " SELECT * FROM `item`  where item_name like '%$keyword%'  ";
                                        echo $keyword ;
                                        
                                        
                                          // คำสั่งเรียง ต้องอยู่หลังสุด 
                                        
                                        $query = mysqli_query($conn, $sql);

                                        if ($result = $conn->query($sql)) {
                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {
                                                    ?>
                                                    <div class="product-item men">
                                                        <div class="product discount product_filter">
                                                            <div class="product_image">
                                                                <img src="images/<?php echo $row['item_image'] ?> " alt="">
                                                            </div>
                                                            <div class="favorite favorite_left"></div>
                <!--                                                    <div class="product_bubble product_bubble_right product_bubble_red d-flex flex-column align-items-center"><span>-$20</span></div>-->
                                                            <div class="product_info">
                                                                <h6 class="product_name"><a href="single.php?id=<?php echo $row['item_id'] ?>  ">  <?php echo $row['item_name'] ?> </a></h6>
                                                                <div class="product_price"><?php echo $row['item_price'] ?>  บาท</div>
                                                                <?php echo $keyword;   ?>
                                                            </div>
                                                        </div>
                                                        <div class="red_button add_to_cart_button"><a href="single.php?id=<?php echo $row['item_id'] ?>  ">add to cart</a></div>
                                                    </div>

                                                    <?php
                                                }
                                            }
                                        }
                                        ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php
        mysqli_close($conn);
        ?>




    </body>
</html>


