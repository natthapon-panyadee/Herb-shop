<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Single Product</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Colo Shop Template">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
        <link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
        <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
        <link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
        <link rel="stylesheet" href="plugins/themify-icons/themify-icons.css">
        <link rel="stylesheet" type="text/css" href="plugins/jquery-ui-1.12.1.custom/jquery-ui.css">
        <link rel="stylesheet" type="text/css" href="styles/single_styles.css">
        <link rel="stylesheet" type="text/css" href="styles/single_responsive.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>


    <body>

        <div class="super_container">

            <!-- Header -->
            <header class="header trans_300">
                <div class="top_nav">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-right">
                                <div class="top_nav_right">
                                    <ul class="top_nav_menu">


                                        <li class="account">
                                            <a href="#">
                                                My Account
                                                <i class="fa fa-angle-down"></i>
                                            </a>
                                            <ul class="account_selection">
                                                <?php
                                                require_once('structure/header_1.php');
                                                ?>

                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 


                <!-- Main Navigation -->
                <?php
                require_once('structure/subheader.php');
                ?>

            </header>

            <div class="fs_menu_overlay"></div>

            <!-- Hamburger Menu -->

            <div class="hamburger_menu">
                <div class="hamburger_close"><i class="fa fa-times" aria-hidden="true"></i></div>
                <div class="hamburger_menu_content text-right">
                    <ul class="menu_top_nav">

                        <li class="menu_item has-children">
                            <a href="#">
                                My Account
                                <i class="fa fa-angle-down"></i>
                            </a>
                            <ul class="menu_selection">
                                <li><a href="#"><i class="fa fa-sign-in" aria-hidden="true"></i>Sign In</a></li>
                                <li><a href="#"><i class="fa fa-user-plus" aria-hidden="true"></i>Register</a></li>
                            </ul>
                        </li>

                    </ul>
                </div>
            </div>

            <div class="container single_product_container">
                <div class="row">
                    <div class="col">

                        <!-- Breadcrumbs -->

                        <div class="breadcrumbs d-flex flex-row align-items-center">
                            <ul>
                                <li><a href="Homepage.php">Home</a></li>                               
                                <li class="active"><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i>Product</a></li>
                            </ul>
                        </div>

                    </div>
                </div>

                <!--Product Detail-->
                <div class="row" style="">      
                    <?php
                    require_once('dbconfig.php');
                    if (isset($_GET['id'])) {
                        $sql = "SELECT * FROM item WHERE item_id = " . $_GET['id'];
                        if ($result = $conn->query($sql)) {
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    ?>
                                    <div class="col-lg-7">
                                        <div class="single_product_pics">
                                            <div class="row">
                                                <div class="col-lg-3 thumbnails_col order-lg-1 order-2">

                                                </div>
                                                <div class="col-lg-9 image_col order-lg-2 order-1">
                                                    <div class="single_product_image">
                                                        <div class="single_product_image_background" style="background-image:url(images/<?php echo $row['item_image'] ?>)"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-5">

                                        <div class="product_details">
                                            <div class="product_details_title">
                                                <input type="hidden"  id="inputid" value=" <?php echo $row['item_id'] ?>">
                                                <h2>   <?php echo $row["item_name"] ?>   </h2>
                                                <p><?php echo $row['descript'] ?></p>
                                            </div>

                                            <div class="original_price"></div>
                                            <div class="product_price"><?php echo $row['item_price'] ?> บาท</div>
                                            
                                            
                                            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                                                    <?php 

                                                        if(isset($_SESSION['user'] )&& $_SESSION['type']==2) {

                                                     ?>
                                                        <div class="red_button add_to_cart_button" >
                                                            <a href="edit.php">Edit</a>
                                                        </div>
                                                    <?php 
                                                        }
                                                     ?>

                                            <div class="quantity d-flex flex-column flex-sm-row align-items-sm-center">

                                                <div class="input-group mb-3">
                                                    <div class="input-group-prepend">
                                                        <label class="input-group-text" for="inputGroupSelect01"><h4>จำนวน : </h4></label>
                                                    </div>
                                                    <select class="custom-select ml-3" id="inputGroupSelect01">
                                                       
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5">5</option>
                                                        <option value="6">6</option>
                                                        <option value="7">7</option>
                                                        <option value="7">8</option>
                                                        <option value="7">9</option>
                                                        <option value="7">10</option>
                                                    </select>
                                                    
                                                    &nbsp&nbsp&nbsp
                                                    
                                                    <div class="input-group-prepend">
                                                        <label class="input-group-text" for="inputGroupSelect01"><h4>  กรัม </h4></label>
                                                    </div>
                                                </div>
                                                <div class="red_button add_to_cart_button"><a href="#" id="btn-addcart">add to cart</a></div>

                                            </div>
                                        </div>

                                    </div>
                                    <?php
                                }
                            }
                        }
                    }
                    ?>
                </div>

            </div>




        </div>


    <!-- <script src="js/js/custom.js"></script> -->


        <script src="js/jquery-3.2.1.min.js"></script>

        <script src="styles/bootstrap4/popper.js"></script>
        <script src="styles/bootstrap4/bootstrap.min.js"></script>
        <script src="plugins/Isotope/isotope.pkgd.min.js"></script>
        <script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
        <script src="plugins/easing/easing.js"></script>
        <script src="plugins/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
        <script src="js/single_custom.js"></script>

        <script type="text/javascript">
            $('#btn-addcart').on('click', function () {

                var id = $('#inputid').val();
                var qty = $('#inputGroupSelect01').val();


                $.ajax({
                    type: "POST",
                    url: "structure/api_addcart.php",
                    data: {

                        'inputid': id,
                        'inputGroupSelect01': qty,

                    },
                    success: function (data) {
                        alert(data);
                        // window.location.href = "login.php";
                    },
                });
            });

        </script>




    </body>

</html>
