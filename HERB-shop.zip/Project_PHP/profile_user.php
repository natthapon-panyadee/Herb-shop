<!DOCTYPE html>
<html lang="en" >

    <head>
        <meta charset="UTF-8">
        <title> Hide/Show Password Login Form</title>
        <meta name="viewport" content="initial-scale=1.0, width=device-width" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
        
        <link rel="stylesheet" href="css/style.css">


    </head>

    <body>

        <div class="login_form">
            <setion class="login-wrapper">

                <div class="logo">
                    <a target="_blank" rel="noopener" href='Homepage.php'>
                        <img src="images/logologin.png" alt=""></a>
                </div>

                <form id="login" method="post" action="#">

                    <label for="username"  >User Name</label>
                    <input  required name="login[username]" type="text"  id="inputUsername" autocapitalize="off" autocorrect="off"/>

                    <label for="password">Password</label>
                    
                    <input class="password" required name="login[password]" type="password" id="inputPassword" />
<!--                    <div class="hide-show">
                        <span>Show</span>
                    </div>-->
                    
                    <button type="submit" id="btn-login" >Sign In</button> 


                </form>
                
                

                </section>
        </div>
        <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>



        <script  src="js/index.js"></script>

        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>


        <script type="text/javascript">
            $('#btn-login').on('click', function () {

                var user = $('#inputUsername').val();
                var password = $('#inputPassword').val();

                $.ajax({
                    type: "POST",
                    url: "structure/api_login.php",
                    data: {

                        'inputUsername': user,
                        'inputPassword': password,

                    },
                    success: function (data) {
                        alert(data);
                        window.location.href = "Homepage.php";
                    },
                });
            });

        </script>

        

    </body>

</html>
