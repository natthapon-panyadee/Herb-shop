<?php

//สร้างการเชื่อมต่อกับฐานข้อมูล

$host="localhost";
$username="root";
$password="";
$db="herbs_shop";

$conn= new mysqli($host,$username,$password,$db);

//if($conn){
//    echo "เชื่อมต่อ $db สำเร็จ";
//}
$conn->query("set names utf8");
