<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <title>แก้ไขรายการสินค้า</title>
    <?php
    // put your code here
    require_once('structure/head.php');
    ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <body>

        <!--Main Top  & Login-->
        <div class="super_container">


            <!--head-->
            <header class="header trans_300">
                <div class="top_nav">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">

                            </div>
                            <div class="col-md-6 text-right">
                                <div class="top_nav_right">
                                    <ul class="top_nav_menu">


                                        <li class="account">
                                            <a href="#">
                                                My Account
                                                <i class="fa fa-angle-down"></i>
                                            </a>
                                            <ul class="account_selection">
                                                <?php
                                                require_once('structure/header_1.php');
                                                ?>

                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> 


                <!-- Main Navigation -->
                <?php
                require_once('structure/subheader.php');
                ?>

            </header><br><br><br><br><br><br><br><br>


            <div class="container">

                <div class="row ">

                    <div class="col-12 col-lg-4 offset-lg-4">

                        <div class="form-group mt-4  ">
                            <label for="exampleInputEmail1" style="color: #33cc00 " style="font-family:'Roboto'">  ชื่อสมุนไพร</style></label>
                            <input type="text" class="form-control" id="nameherbs" aria-describedby="emailHelp" placeholder="ชื่อสมุนไพร">

                        </div>

                        
                        <div class="form-group">
                             <label for="exampleInputPassword1">ชนิดของสมุนไพร</label><br>
                            <select id="typeherbs">
                              <option value="สมุนไพรไทย">สมุนไพรไทย</option>
                              <option value="สมุนไพรจีน">สมุนไพรจีน</option>
                              
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword1">สรรพคุณ</label>
                            <textarea type="password" class="form-control" id="detailherbs" placeholder="สรรพคุณ"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword1">ราคางาน</label>
                            <input type="number" class="form-control" id="price" placeholder="xxxx บาท">
                        </div>

                        <div class="form-group">

                            <input type="file" name="uploadfile" id="uploadfile" accept="image/x-png,image/gif,image/jpeg"/>
                            <!-- <input type="submit"   /> -->
                        </div>

                        <div class="form-group mt-4">
                            <div class="col-4 offset-lg-4">
                                <button id="btn-post" value="upload"  class="btn btn-danger rounded pl-4 pr-4" style="background-color: #2f3638 !important; border-color: #76b6c2">ประกาศ</button>
                            </div>
                        </div>

                    </div>
                </div>

            </div>




            <script type="text/javascript">
                $('#btn-post').on('click', function () {
                    var nameherb = $('#nameherbs').val();
                    var type = $('#typeherbs').val();
                    var detailherbs = $('#detailherbs').val();
                    var price = $('#price').val();

                    var formData = new FormData();

                    formData.append('nameherbs', nameherb);
                    formData.append('typeherbs', type);
                    formData.append('detailherbs', detailherbs);
                    formData.append('price', price);


                    if ($('input#uploadfile')[0].files[0]) {
                        formData.append('uploadfile', $('input#uploadfile')[0].files[0]);
                        formData.append('iuploadfile', 1);
                    } else {
                        formData.append('iuploadfile', 0);
                    }



                    $.ajax({
                        type: "POST",
                        mimeTypes: "multipart/form-data",
                        url: "structure/api_post_item.php",
                        contentType: false,
                        processData: false,
                        data: formData,
                        success: function (data) {
                            alert(data);
                            // window.location.href = "allwork.php";
                        },
                        error: function (xhr, status, error) {
                            var err = eval("(" + xhr.responseText + ")");
                            alert(err.Message);

                        }
                    });



                });


            </script>


        </div>

    </body>

</html>
